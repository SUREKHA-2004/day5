package com.myproject.demo.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
//import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.myproject.demo.model.Student;
import com.myproject.demo.repository.StudentRepository;

@Service
public class StudentService {
	@Autowired
	StudentRepository studRepository;
	
	public List<Student> getAllStudents()
	{
		List<Student> studList=studRepository.findAll();
		return studList;
	}
	
	public Student saveStudent (Student s)
	{
		return studRepository.save(s);
	}

	public Student deleteStudent(int rollno)
	{
		studRepository.deleteById(rollno);
		return null; 
	}
	public Student getStudent(int rollno) {
		return studRepository.findById(rollno).get();
	}

	public List<Student> sortStudents(String rollno) {
			
		 return studRepository.findAll(Sort.by(rollno));
	}

	public List<Student> getpagingStudent(@PathVariable int offset, @PathVariable int pagesize) 
	{
		
		Page <Student> page=studRepository.findAll(PageRequest.of(offset, pagesize));
		return page.getContent();
	}
	

}
