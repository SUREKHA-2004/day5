package com.myproject.demo.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.myproject.demo.model.Student;
import com.myproject.demo.service.StudentService;

@RestController
public class StudentController {
	@Autowired
	StudentService studService;
	@GetMapping(value="/fetchStudents")
	public List<Student> getAllStudents()
	{
		List<Student> studList=studService.getAllStudents();
		return studList;
	}
	@PostMapping(value="/saveStudents")
	public Student saveStudent(@RequestBody Student s) 
	{
		return studService.saveStudent(s);
	}
	
	@PutMapping(value="/updateStudents")
	public Student updateStudent(@RequestBody Student s)
	{
		return studService.saveStudent(s);
	}
	@DeleteMapping("/deleStudents/{rno}")
	public void deleteStudent(@PathVariable("rno") int rollno)
	{
		 studService.deleteStudent(rollno);
	}
	@GetMapping(value="/getStudents/{rno}")
	public Student getStudent(@PathVariable("rno") int rollno)
	{
		return studService.getStudent(rollno);
	}
	@GetMapping(value="/sortStudents/{sort}")
	public List<Student> sortStudents(@PathVariable("sort") String rollno)
	{
		return studService.sortStudents(rollno);
	}
	@GetMapping(value="/page/{offset}/{pagesize}")
	public List<Student> getStudentDetails(@PathVariable int offset,@PathVariable int pagesize)
	{
		return studService.getpagingStudent(offset,pagesize);
	}
	
}
